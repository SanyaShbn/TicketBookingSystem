create function check_rows_numb_func() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.available_rows_numb > NEW.max_rows_numb THEN
        RAISE EXCEPTION 'ERROR_CHECK_ROWS';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_rows_numb_func() owner to postgres;

