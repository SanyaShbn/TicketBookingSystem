create function check_ticket_references() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM ticket
        WHERE event_id = NEW.id
    ) THEN
        RAISE EXCEPTION 'EVENT_REFERENCE_EXCEPTION: Cannot update or delete sport_event with existing ticket references';
    END IF;

    RETURN NEW;
END;
$$;

alter function check_ticket_references() owner to postgres;

