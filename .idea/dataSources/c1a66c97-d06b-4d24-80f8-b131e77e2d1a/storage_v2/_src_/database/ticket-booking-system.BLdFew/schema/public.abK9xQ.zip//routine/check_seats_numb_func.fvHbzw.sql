create function check_seats_numb_func() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.available_seats_numb > NEW.max_seats_numb THEN
        RAISE EXCEPTION 'ERROR_CHECK_SEATS';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_seats_numb_func() owner to postgres;

