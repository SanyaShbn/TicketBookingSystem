create function check_capacity() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.capacity < NEW.general_seats_numb THEN
        RAISE EXCEPTION 'ERROR_CHECK_CAPACITY';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_capacity() owner to postgres;

