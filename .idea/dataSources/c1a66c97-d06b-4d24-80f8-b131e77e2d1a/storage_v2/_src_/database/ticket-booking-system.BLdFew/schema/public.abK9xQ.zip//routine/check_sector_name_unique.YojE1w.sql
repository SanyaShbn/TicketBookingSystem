create function check_sector_name_unique() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM sector
        WHERE arena_id = NEW.arena_id
          AND sector_name = NEW.sector_name
          AND id <> NEW.id) THEN
        RAISE EXCEPTION 'ERROR_CHECK_SECTOR_NAME';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_sector_name_unique() owner to postgres;

