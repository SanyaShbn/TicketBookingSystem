create function update_seats() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Удаляем старые записи
    DELETE FROM seat WHERE row_id = NEW.id;

    -- Создаем новые записи
    FOR i IN 1..NEW.seats_numb LOOP
            INSERT INTO seat (row_id, seat_number) VALUES (NEW.id, i);
        END LOOP;

    RETURN NEW;
END;
$$;

alter function update_seats() owner to postgres;

