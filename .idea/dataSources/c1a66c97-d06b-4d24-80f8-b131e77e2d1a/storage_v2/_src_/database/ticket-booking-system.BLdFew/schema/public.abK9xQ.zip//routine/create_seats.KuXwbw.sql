create function create_seats() returns trigger
    language plpgsql
as
$$
DECLARE
    i INT;
BEGIN
    FOR i IN 1..NEW.seats_numb LOOP
            INSERT INTO seat (row_id, seat_number) VALUES (NEW.id, i);
        END LOOP;
    RETURN NEW;
END;
$$;

alter function create_seats() owner to postgres;

