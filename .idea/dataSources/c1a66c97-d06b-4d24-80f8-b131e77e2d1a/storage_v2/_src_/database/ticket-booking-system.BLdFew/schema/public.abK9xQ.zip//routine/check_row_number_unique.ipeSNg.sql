create function check_row_number_unique() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM row
        WHERE sector_id = NEW.sector_id
          AND row_number = NEW.row_number
          AND id <> NEW.id) THEN
        RAISE EXCEPTION 'ERROR_CHECK_ROW_NUMBER';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_row_number_unique() owner to postgres;

