create function check_event_time() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Проверяем на наличие пересечения событий с одинаковым arena_id, исключая текущую запись
    IF EXISTS (
        SELECT 1
        FROM sport_event
        WHERE
                arena_id = NEW.arena_id
          AND id != NEW.id
          AND (
                    event_date_time = NEW.event_date_time
                OR ABS(EXTRACT(EPOCH FROM (NEW.event_date_time - event_date_time))) < 10800
            )
    ) THEN
        RAISE EXCEPTION 'EVENT_TIME_EXCEPTION: Event already exists at the same time or within 3 hours interval for the same arena';
    END IF;

    RETURN NEW;
END;
$$;

alter function check_event_time() owner to postgres;

